import numpy as np
from .Individuo import Individuo
from .EHO import EHO