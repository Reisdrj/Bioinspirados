import numpy as np
from .Individuo import Individuo
from .AG import AlgoritmoGenetico